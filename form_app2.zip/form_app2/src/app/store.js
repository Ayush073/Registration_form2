// src/app/store.js

import { configureStore } from '@reduxjs/toolkit';
import userRegistrationReducer from '../features/userRegistrationSlice';

export const store = configureStore({
  reducer: {
    userRegistration: userRegistrationReducer,
  },
});
