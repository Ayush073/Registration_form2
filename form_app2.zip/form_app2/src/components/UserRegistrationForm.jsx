// src/components/UserRegistrationForm.jsx

import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { TextField, Button } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { setStep } from '../features/userRegistrationSlice';
import { yupResolver } from '@hookform/resolvers/yup'; // Correct import
import * as yup from 'yup';
import '../styles/UserRegistrationForm.css'; 

const UserRegistrationForm = () => {
  const dispatch = useDispatch();
  const { step } = useSelector((state) => state.userRegistration);

  const schema = yup.object().shape({
    firstName: yup.string().required('First Name is required'),
    lastName: yup.string().required('Last Name is required'),
    email: yup.string().email('Invalid email').required('Email is required'),
    password: yup.string().min(8, 'Password must be at least 8 characters').required('Password is required'),
  });

  const { handleSubmit, control } = useForm({
    resolver: yupResolver(schema),
  });

  const onSubmit = (data) => {
    if (step === 1) {
      dispatch(setStep(2));
    } else {
      // Handle form submission (e.g., dispatch an action or make an API call)
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Controller
        name="firstName"
        control={control}
        render={({ field, fieldState }) => (
          <TextField label="First Name" {...field} error={!!fieldState.error} helperText={fieldState.error?.message} />
        )}
      />
      <Controller
        name="lastName"
        control={control}
        render={({ field, fieldState }) => (
          <TextField label="Last Name" {...field} error={!!fieldState.error} helperText={fieldState.error?.message} />
        )}
      />
      {step === 2 && (
        <>
          <Controller
            name="email"
            control={control}
            render={({ field, fieldState }) => (
              <TextField label="Email" {...field} error={!!fieldState.error} helperText={fieldState.error?.message} />
            )}
          />
          <Controller
            name="password"
            control={control}
            render={({ field, fieldState }) => (
              <TextField label="Password" type="password" {...field} error={!!fieldState.error} helperText={fieldState.error?.message} />
            )}
          />
        </>
      )}
      <Button type="submit" variant="contained" color="primary">
        {step === 1 ? 'Next' : 'Submit'}
      </Button>
    </form>
  );
};

export default UserRegistrationForm;
