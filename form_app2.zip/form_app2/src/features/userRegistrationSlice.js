// src/features/userRegistrationSlice.js

import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

export const registerUser = createAsyncThunk('userRegistration/registerUser', async (userData) => {
  // Add your registration logic here (e.g., API call to register the user)
  // Simulating a delay for demonstration purposes
  await new Promise(resolve => setTimeout(resolve, 1000));
  return userData;
});

const userRegistrationSlice = createSlice({
  name: 'userRegistration',
  initialState: {
    step: 1,
    userData: {},
    status: 'idle',
  },
  reducers: {
    setStep: (state, action) => {
      state.step = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(registerUser.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(registerUser.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.userData = action.payload;
      });
  },
});

export const { setStep } = userRegistrationSlice.actions;
export default userRegistrationSlice.reducer;
