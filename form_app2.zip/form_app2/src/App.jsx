// App.js

import React from 'react';
import { Provider } from 'react-redux';
import { store } from './app/store';
import UserRegistrationForm from './components/UserRegistrationForm';

function App() {
  return (
    <Provider store={store}>
      <div>
        <UserRegistrationForm />
      </div>
    </Provider>
  );
}

export default App;
